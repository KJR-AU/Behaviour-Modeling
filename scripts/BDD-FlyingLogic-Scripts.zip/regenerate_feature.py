#regenerate feature files from AST

#TODO
# load ast for the feature being regenerated 

import os
import pickle
import sys
sys.path.append("/Library/Python/2.7/site-packages")
from javax.swing import Box, BoxLayout, JLabel, JCheckBox, JComboBox, JTextField

#get selected nodes
count=0
merged=[]
#iterate through the selection - keep first node and remove all others, transferring edges to the first node
#print 'selected:', len(document.selection)
if len(document.selection) < 1 :
       Application.alert('You must select at least one nodes within the feature you wish to update.')

featureFileName = None
feature = None

for ge in document.selection:
          #get the filename of the feature for this node
          featureFileName = ge.user['filename']
          baseName = os.path.basename(featureFileName)
          dirName = os.path.dirname(featureFileName)
          pickleBaseName = os.path.splitext(baseName)[0] + '.pickle'
          pickleFilePath = os.path.join(dirName,pickleBaseName)
          #load the pickled AST for this feature
          feature = pickle.load(open(pickleFilePath, "rb"))

          #iterate through the AST, building up the output text in order of line number
          for key,value in feature.items():
             if (key == 'comments'):
                 for comment in value:
                     print comment['text'] 
             elif (key == 'tag'):
                 for tag in value:
                     print tag['text'] 
             elif (key == ''):

          #update feature file 
          #with open(featureFileName, 'w') as pickleHandle:
          #      pickle.dump(feature, pickleHandle)

document.clearSelection()
#print "Done"
#Application.alert("Feature file updated")

